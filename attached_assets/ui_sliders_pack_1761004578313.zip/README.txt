
# Open-Source UX/UI Sliders Pack (2025)

Three cutting-edge, open-source slider/scroll components for web UI design.
Each text file provides overview, features, and install instructions.

Included:
1. Swiper (JS/React/Vue) — Full-featured responsive slider.
2. react-slider — Lightweight accessible React slider.
3. shadcn/ui Slider — Modern Tailwind + Radix-based slider.

All projects are MIT or permissive licenses.

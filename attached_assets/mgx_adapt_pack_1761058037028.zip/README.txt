
MGX-Style UX/UI Adapt Pack (Replit-ready, text files)

Purpose: Add MGX-like motion, glass, and background energy to your existing site without changing structure.
Deps: react 18, framer-motion, tailwindcss (already in your project).

Files:
1) themeTokens.txt         — Central color/gradient tokens with CSS vars.
2) useDynamicHue.txt       — Shared hook for time + pointer-driven hue.
3) glassPanel.txt          — Glassmorphic motion panel wrapper.
4) fxBackground.txt        — Energy background (2D gradients + particles).
5) flowLayout.txt          — Layout frame with dock/toolbar and slot for your content.

How to integrate:
- Create /src/ui/ and add these files (rename .txt -> .tsx or .ts as indicated in each header).
- Import <FlowLayout> in your App and wrap your existing content:
  import FlowLayout from './ui/flowLayout'
  import FxBackground from './ui/fxBackground'
  ...
  <FlowLayout>
    <FxBackground />
    {existing app content}
  </FlowLayout>

- Replace static container cards with <GlassPanel> for “MGX glass” look.
- Ensure Tailwind is loaded and body background is not overriding the FxBackground layer.

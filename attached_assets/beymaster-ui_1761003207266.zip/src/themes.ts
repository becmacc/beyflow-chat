
export type ThemeKey = 'beycore' | 'beyuni' | 'beytech' | 'beyspace' | 'wearwolf' | 'alamac';

export const THEMES: { key: ThemeKey; label: string; persona: string }[] = [
  { key: 'beycore', label: 'BeyCore', persona: 'Founder / Command' },
  { key: 'beyuni', label: 'BeyUni', persona: 'Educator / Thinker' },
  { key: 'beytech', label: 'BeyTech', persona: 'Engineer / Builder' },
  { key: 'beyspace', label: 'BeySpace', persona: 'Futurist / Visionary' },
  { key: 'wearwolf', label: 'WearWolf', persona: 'Rebel / Creator' },
  { key: 'alamac', label: 'ALAMAC', persona: 'Archivist / Sage' },
];


import React from 'react'
import { ThemeProvider } from './components/ui/ThemeProvider'
import ThemeSwitcher from './components/ui/ThemeSwitcher'
import ModernUIPack from './components/ui/ModernUIPack'

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen px-6 py-10 md:py-14 md:px-10">
        <header className="flex items-center justify-between mb-10">
          <div className="text-xl font-semibold">BeyMaster UI</div>
          <div className="pill">Multi-Persona Theme System</div>
        </header>

        <div className="grid md:grid-cols-2 gap-10">
          <ThemeSwitcher />
          <ModernUIPack />
        </div>
      </div>
    </ThemeProvider>
  )
}


import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import type { ThemeKey } from '../../themes'

type Ctx = { theme: ThemeKey; setTheme: (t: ThemeKey) => void }
const ThemeCtx = createContext<Ctx | null>(null)

const KEY = 'bey.theme'

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeKey>(() => {
    const saved = localStorage.getItem(KEY) as ThemeKey | null
    return saved ?? 'beycore'
  })

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
    localStorage.setItem(KEY, theme)
  }, [theme])

  const value = useMemo(() => ({ theme, setTheme }), [theme])
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>
}

export function useTheme() {
  const v = useContext(ThemeCtx)
  if (!v) throw new Error('useTheme must be used within ThemeProvider')
  return v
}

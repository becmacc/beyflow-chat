
import React from 'react'
import { motion } from 'framer-motion'
import { THEMES } from '../../themes'
import { useTheme } from './ThemeProvider'

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()
  return (
    <div className="panel">
      <div className="mb-3 text-sm opacity-80">Persona Themes</div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {THEMES.map(t => (
          <button
            key={t.key}
            onClick={() => setTheme(t.key)}
            className="relative overflow-hidden rounded-2xl border border-white/10 p-4 text-left"
          >
            {theme === t.key && (
              <motion.span
                layoutId="themeSelect"
                className="absolute inset-0"
                style={{ boxShadow: 'inset 0 0 0 2px var(--accent)', borderRadius: 16 }}
                transition={{ type: 'spring', stiffness: 300, damping: 25, mass: 0.6 }}
              />
            )}
            <div className="font-medium">{t.label}</div>
            <div className="text-xs opacity-75">{t.persona}</div>
          </button>
        ))}
      </div>
    </div>
  )
}

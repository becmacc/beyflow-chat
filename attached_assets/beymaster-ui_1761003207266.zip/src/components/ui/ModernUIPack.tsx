
import React, { useEffect, useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform, LayoutGroup } from 'framer-motion'

function MagneticButton({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLButtonElement | null>(null)
  const x = useMotionValue(0), y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 150, damping: 10, mass: 0.4 })
  const sy = useSpring(y, { stiffness: 150, damping: 10, mass: 0.4 })

  useEffect(() => {
    const el = ref.current; if (!el) return
    const rect = () => el.getBoundingClientRect()
    function onMove(e: MouseEvent) {
      const r = rect()
      const mx = e.clientX - (r.left + r.width / 2)
      const my = e.clientY - (r.top + r.height / 2)
      x.set(Math.max(-20, Math.min(20, mx * 0.25)))
      y.set(Math.max(-20, Math.min(20, my * 0.25)))
    }
    function onLeave(){ x.set(0); y.set(0) }
    el.addEventListener('mousemove', onMove)
    el.addEventListener('mouseleave', onLeave)
    return () => { el.removeEventListener('mousemove', onMove); el.removeEventListener('mouseleave', onLeave) }
  }, [x, y])

  const rotate = useTransform([sx, sy], ([vx, vy]) => (Number(vx) * 0.15) + (Number(vy) * 0.1))

  return (
    <motion.button
      ref={ref}
      style={{ x: sx, y: sy, rotate }}
      className="btn"
    >
      {children}
    </motion.button>
  )
}

function JellyCard() {
  return (
    <motion.div
      initial={{ scale: 1, rotate: 0 }}
      whileHover={{ scale: 1.04, rotate: 0.3, skewX: 0.6, skewY: -0.4 }}
      transition={{ type: 'spring', stiffness: 220, damping: 12, mass: 0.6 }}
      className="panel"
    >
      <div className="text-lg font-semibold mb-1">Jelly Card</div>
      <div className="opacity-80 text-sm">Elastic hover with subtle tilt and wobble.</div>
    </motion.div>
  )
}

function WobblyTabs() {
  const [tab, setTab] = React.useState<'Overview' | 'Specs' | 'Reviews'>('Overview')
  const tabs: typeof tab[] = ['Overview', 'Specs', 'Reviews']
  return (
    <LayoutGroup>
      <div className="inline-flex p-1 rounded-2xl border border-white/10">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)} className={`relative px-4 py-2 rounded-xl text-sm ${tab === t ? 'text-black' : 'opacity-80'}`}>
            {tab === t && (
              <motion.span
                layoutId="pill"
                transition={{ type: 'spring', stiffness: 300, damping: 20, mass: 0.6 }}
                className="absolute inset-0 bg-white rounded-xl"
              />
            )}
            <span className="relative z-10">{t}</span>
          </button>
        ))}
      </div>
    </LayoutGroup>
  )
}

function LiquidLoader() {
  return (
    <div className="relative w-48 h-24">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 100">
        <defs>
          <filter id="goo"><feGaussianBlur in="SourceGraphic" stdDeviation="6"/><feColorMatrix values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -10"/><feBlend/></filter>
          <linearGradient id="grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)"/>
            <stop offset="100%" stopColor="var(--accent)"/>
          </linearGradient>
        </defs>
        <g style={{ filter: 'url(#goo)' }}>
          <motion.circle cx="60" cy="50" r="16" fill="url(#grad)"
            animate={{ cx: [50, 65, 55, 60], cy: [50, 48, 54, 50] }}
            transition={{ repeat: Infinity, duration: 2.4, ease: 'easeInOut' }} />
          <motion.circle cx="100" cy="50" r="16" fill="url(#grad)"
            animate={{ cx: [100, 115, 95, 100], cy: [50, 52, 47, 50] }}
            transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }} />
          <motion.circle cx="140" cy="50" r="16" fill="url(#grad)"
            animate={{ cx: [140, 130, 145, 140], cy: [50, 55, 49, 50] }}
            transition={{ repeat: Infinity, duration: 2.6, ease: 'easeInOut' }} />
        </g>
      </svg>
    </div>
  )
}

export default function ModernUIPack() {
  return (
    <div className="grid gap-8">
      <div className="panel max-w-md">
        <div className="text-2xl font-semibold mb-4">Glassmorphism Login</div>
        <input placeholder="Email" className="input mb-3" />
        <input type="password" placeholder="Password" className="input mb-4" />
        <div className="flex items-center justify-between mb-6 text-sm opacity-80">
          <label className="inline-flex items-center gap-2"><input type="checkbox"/><span>Remember</span></label>
          <a href="#" className="underline">Forgot?</a>
        </div>
        <MagneticButton>Login</MagneticButton>
      </div>

      <JellyCard />
      <WobblyTabs />
      <LiquidLoader />

      <div className="panel max-w-md">
        <div className="text-lg font-semibold mb-3">AI Smart Speaker</div>
        <motion.img
          src="https://images.unsplash.com/photo-1585386959984-a41552231693"
          alt="AI Speaker"
          className="rounded-2xl mb-3"
          whileHover={{ scale: 1.05, rotate: 0.4 }}
          transition={{ type: 'spring', stiffness: 220, damping: 14 }}
        />
        <button className="btn w-full">Add to Cart</button>
      </div>
    </div>
  )
}

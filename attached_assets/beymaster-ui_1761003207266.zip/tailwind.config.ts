
import type { Config } from 'tailwindcss'

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      borderRadius: {
        '2xl': '1.25rem',
        '3xl': '1.75rem',
      },
      boxShadow: {
        'elev-1': '0 6px 20px rgba(0,0,0,0.25)',
        'elev-2': '0 12px 40px rgba(0,0,0,0.35)',
      }
    },
  },
  plugins: [],
} satisfies Config

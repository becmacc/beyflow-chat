
# BeyMaster UI — Vite + React + Tailwind (2025)

Multi-persona theme system for BeyMedia with animated wobble UI.

## Run
```bash
npm i
npm run dev
```

If using Replit, ensure `vite.config.ts` has `server.host = true` and your allowed proxy host.
